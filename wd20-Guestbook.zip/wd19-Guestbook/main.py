#!/usr/bin/env python
import os
import time
import jinja2
import webapp2
from models import Message


template_dir = os.path.join(os.path.dirname(__file__), "templates")
jinja_env = jinja2.Environment(loader=jinja2.FileSystemLoader(template_dir), autoescape=False)


class BaseHandler(webapp2.RequestHandler):

    def write(self, *a, **kw):
        return self.response.out.write(*a, **kw)

    def render_str(self, template, **params):
        t = jinja_env.get_template(template)
        return t.render(params)

    def render(self, template, **kw):
        return self.write(self.render_str(template, **kw))

    def render_template(self, view_filename, params=None):
        if params is None:
            params = {}
        template = jinja_env.get_template(view_filename)
        return self.response.out.write(template.render(params))


class MainHandler(BaseHandler):
    def get(self):
        #message = "..."
        #websitetime = time.asctime(time.localtime())
        #params = {"message": message, "websitetime": websitetime}

        messages = Message.query(Message.deleted == False).fetch()
        params = {"messages": messages}

        return self.render_template("guestbook.html", params=params)

class EntryHandler(BaseHandler):

    def post(self):
        #Constant
        entry_name = self.request.get("name")

        if entry_name=="<script>":
            return self.write("TREFFER")

        if entry_name=="":
            entry_name="Anonymous"
        #Optional
        entry_email = self.request.get("email")
        #Non-Optional
        entry_text = self.request.get("text")
        if entry_text == "":
            return self.write("Text wurde nicht eingegeben. Eintrag wird nicht in dem DataStore gespeichert.")
        else:
            msg = Message(message_name = entry_name, message_email = entry_email, message_text = entry_text)
            msg.put()
            return self.get()

    def get(self):
        messages = Message.query().fetch()
        params = {"messages": messages}
        #return self.render_template("entry.html", params=params)
        return self.redirect_to("guestbook")

class EditHandler(BaseHandler):
    def get(self, message_id):
        message = Message.get_by_id(int(message_id))
        params = { "message": message }
        return self.render_template("edit.html", params=params)

    def post(self, message_id):
        new_name = self.request.get("name")
        new_text = self.request.get("text")
        new_email = self.request.get("email")
        message = Message.get_by_id(int(message_id))
        message.message_name = new_name
        message.message_text = new_text
        message.message_email = new_email
        message.put()
        return self.redirect_to("guestbook")

class DeleteHandler(BaseHandler):
    def get(self, message_id):
        message = Message.get_by_id(int(message_id))
        params = {"message": message}
        return self.render_template("delete.html", params=params)

    def post(self,message_id):
        message = Message.get_by_id(int(message_id))
        message.deleted = True
        message.put()
        return self.redirect_to("guestbook")

class HistoryHandler(BaseHandler):
    def get(self):
        messages = Message.query(Message.deleted == True).fetch()
        params = {"messages": messages}
        return self.render_template("history.html", params=params)

class EraseHandler(BaseHandler):
    def get(self, message_id):
            message = Message.get_by_id(int(message_id))
            params = {"message": message}
            return self.render_template("erase.html", params=params)

    def post(self, message_id):
        message = Message.get_by_id(int(message_id))
        message.key.delete()
        return self.redirect_to("guestbook")

class RestoreHandler(BaseHandler):
    def get(self,message_id):
        message = Message.get_by_id(int(message_id))
        params = {"message": message}
        return self.render_template("restore.html", params=params)

    def post(self,message_id):
        message = Message.get_by_id(int(message_id))
        message.deleted = False
        message.put()
        return self.redirect_to("guestbook")

app = webapp2.WSGIApplication([
    webapp2.Route('/', MainHandler, name="guestbook"),
    webapp2.Route('/entry.html',EntryHandler),
    webapp2.Route('/entry/<message_id:\d+>', EditHandler),
    webapp2.Route('/entry/<message_id:\d+>/delete', DeleteHandler),
    webapp2.Route('/history', HistoryHandler),
    webapp2.Route('/history/<message_id:\d+>/erase',EraseHandler),
    webapp2.Route('/history/<message_id:\d+>/restore',RestoreHandler)
], debug=True)