from google.appengine.ext import ndb

class Message(ndb.Model):
    message_name = ndb.StringProperty()
    message_email = ndb.StringProperty()
    message_text = ndb.TextProperty()
    created = ndb.DateTimeProperty(auto_now_add=True)
    deleted = ndb.BooleanProperty(default=False)